<!-- Rodapé -->
<footer class="bg-footer text-dark text-center py-2 mt-auto d-flex justify-content-center">
    <p class="fs-6 mb-0 fw-bold">&copy; 2024 HigiPest - Todos os direitos reservados</p>
</footer>
