<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HigiPest - Serviços</title>

    <!-- Bootstrap e CSS -->
    <link rel="stylesheet" href="/web/assets/styles/bootstrap.css">
    <link rel="stylesheet" href="/web/assets/styles/bootstrap.min.css">
    <link rel="stylesheet" href="/web/assets/styles/styles.css">
    
</head>
<body>

    <!-- menu -->
    <?php require('components/menu.php'); ?> <!-- Inclui o menu aqui -->

    <!-- cabeçalho -->
    <section id="hero" class="text-white text-center py-5" style="background-color: #ff8800;">
        <div class="container">
            <h1 class="display-4 fw-bold">Serviços</h1>
            <p class="lead">Eliminamos pragas de forma eficaz e segura. Proteja a sua casa ou empresa.</p>
        </div>
    </section>

    <!-- Serviços -->
    <section id="servicos" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Nossos Serviços</h2>

            <div class="row">
                <!-- Desratização -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <img src="\web\assets\img\300x200.png" class="card-img-top" alt="Desratização"> <!-- img 300x200 para desratização -->
                        <div class="card-body">
                            <h5 class="card-title">Desratização</h5>
                            <p class="card-text">Garantimos a eliminação eficiente de ratos com métodos seguros e rápidos para sua residência ou empresa.</p>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>

                <!-- Desbaratização -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <img src="\web\assets\img\300x200.png" class="card-img-top" alt="Desbaratização"> <!-- img 300x200 para desbaratização -->
                        <div class="card-body">
                            <h5 class="card-title">Desbaratização</h5>
                            <p class="card-text">A desbaratização refere-se aos tratamentos específicos para o controlo eficaz de baratas, garantindo ambientes mais higiénicos e seguros.</p>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Desinfestação -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <img src="\web\assets\img\300x200.png" class="card-img-top" alt="Desinfestação"> <!-- img 300x200 para desinfestação -->
                        <div class="card-body">
                            <h5 class="card-title">Desinfestação</h5>
                            <p class="card-text">Eliminamos agentes patogénicos através de tratamentos personalizados e adaptados a cada tipo de praga. Garantimos máxima eficácia, segurança e a qualidade de um serviço profissional, assegurando um ambiente mais saudável e protegido.</p>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>

                <!-- Tratamento de Madeiras -->
                <div class="col-md-6 mb-4">
                    <div class="card shadow-sm">
                        <img src="\web\assets\img\300x200.png" class="card-img-top" alt="Tratamento de madeiras"> <!-- img 300x200 para tratamento de Madeiras -->
                        <div class="card-body">
                            <h5 class="card-title">Tratamentos de Madeira</h5>
                            <p class="card-text">
                            Os insetos que infestam a madeira são perigosos, causando danos difíceis de perceber até serem significativos. Os nossos tratamentos especializados protegem e preservam a madeira, prevenindo prejuízos.</p>
                            <a href="#" class="btn btn-primary">Saiba Mais</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>

    <!-- Footer -->
    <?php require('components/footer.php'); ?> <!-- Inclui o footer aqui -->

    <!-- Bootstrap JS, Popper.js e jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>

</body>
</html>
