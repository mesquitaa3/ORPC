<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HigiPest - Pragas</title>

    <!-- Bootstrap e CSS -->
    <link rel="stylesheet" href="/web/assets/styles/bootstrap.css">
    <link rel="stylesheet" href="/web/assets/styles/bootstrap.min.css">
    <link rel="stylesheet" href="/web/assets/styles/styles.css">
    
</head>
<body>

    <!-- Menu -->
    <?php require('components/menu.php'); ?> <!-- Inclui o menu -->

    <!-- Cabeçalho -->
    <section class="text-white text-center py-5" style="background-color: #ff8800;">
        <div class="container">
            <h1 class="display-4 fw-bold">Pragas</h1>
            <p class="lead">Saiba mais sobre as pragas mais comuns e como lidar com elas de forma eficaz.</p>
        </div>
    </section>

    <!-- Texto sobre Pragas -->
    <section id="sobre-pragas" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Pragas? O que são?</h2>
            <p class="text-center mb-4">As pragas são organismos que interferem na saúde, segurança e bem-estar das pessoas, assim como nas atividades agrícolas e industriais. Podem incluir insetos, roedores, aves e até microrganismos.</p>
            <p class="text-center">O controlo de pragas é essencial para prevenir doenças, proteger estruturas e manter um ambiente seguro e saudável.</p>
        </div>
    </section>

    <!-- Tipos de Pragas -->
    <section id="tipos-pragas" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Tipos de Pragas</h2>
            <div class="row">
                <!-- Ratos -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Ratos">
                        <div class="card-body">
                            <h5 class="card-title">Ratos</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>

                <!-- Baratas -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Baratas">
                        <div class="card-body">
                            <h5 class="card-title">Baratas</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>

                <!-- Formigas -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Formigas">
                        <div class="card-body">
                            <h5 class="card-title">Formigas</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <!-- Pombos -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Pombos">
                        <div class="card-body">
                            <h5 class="card-title">Pombos</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>

                <!-- Mosquitos -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Mosquitos">
                        <div class="card-body">
                            <h5 class="card-title">Mosquitos</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>

                <!-- Caruncho -->
                <div class="col-md-4 mb-4">
                    <div class="card shadow-sm">
                        <img src="https://via.placeholder.com/300x200" class="card-img-top" alt="Caruncho">
                        <div class="card-body">
                            <h5 class="card-title">Caruncho</h5>
                            <p class="card-text">texto texto texto</p>
                            <a href="#" class="btn btn-primary">Soluções</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <?php require('components/footer.php'); ?> <!-- Inclui o footer aqui -->

    <!-- Bootstrap JS, Popper.js e jQuery -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"></script>

</body>
</html>
